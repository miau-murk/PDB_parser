# usage
```
replacement -i input.mol -o output.sdf -before CH3 -after Cl
```

-i input file

-o output file. if SDF, all replacements will be written to the same sdf. If other formats, one file will be created for each replacement.

-before: specify group that needs to be replaced. Format:
   {element}[H{n}]
   for example: CH3, NH, OH, NH2, Cl, F etc
-after: specify new group. Format is the same

additional options: 

-implicitH  
   when option is enabled, any number of H will match. 
   
-all_atoms
   when option is disabled (by default) replacements will be done only for atoms connected to C. For example, terminal N-CH3 will not be replaced by Cl in the replacement CH3->Cl. When option is enabled, restrictions will no longer be applied.
   
   
# examples
```
replacement -i test_C2.mol -o output.pdb -before CH3 -after Cl 
```
will make 2 replacements, and create 2 output pdb file


```
replacement -i test_C2.mol -o output.pdb -before CH3 -after NH3 -all_atoms
```
will make 3 replacements (including N-NH3) 


```
replacement -i test_C2.mol -o output.pdb -before F -after H
```
will make 2 F->H replacements


```
replacement -i test_C2.mol -o output.pdb -before C -after F -implicitH
```
will make 2 CH3->F replacements
